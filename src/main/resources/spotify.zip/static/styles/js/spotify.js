

$( "#main" ).css( "display", "none" );
let refresh_token=localStorage.getItem("refresh_token")

if (!refresh_token || typeof refresh_token === "undefined" || refresh_token == "undefined"){
    refresh_token=null
}
$("#reload_all").on("click",()=>{
    localStorage.clear();
    window.location = window.location.href.split("?")[0];
});

var client_id = localStorage.getItem("client_id") == undefined ?null:localStorage.getItem("client_id")
var access_token =null
var all_songs = []
function formate_Date(date){

    let  aux= new Date(date);
    let time = Math.round(new Date()-aux)/1000 ;
      if(time < 60){
        let cad = `hace ${time} segundo`
        if (time > 1){
          cad+="s"
        }
        return cad
      }
      time = Math.round(time/60)
      if (time < 60){
          let cad = `hace ${time} minutoo`
        if (time > 1){
          cad+="s"
        }
        return cad
      }
       time = Math.round(time/60)
      if (time < 24){
         let cad = `hace ${time} hora`
        if (time > 1){
          cad+="s"
        }
        return cad
      }
       time = Math.round(time/24)
       if (time < 7){
         let cad = `hace ${time} día`
        if (time > 1){
          cad+="s"
        }
        return cad
      }
        time = Math.round(time/7)
       if (time < 5){
         let cad = `hace ${time} semana`
        if (time > 1){
          cad+="s"
        }
        return cad
      }
      
      let month_name = aux.toLocaleDateString("es-MX",{month:"long"})
      let year = aux.getFullYear()
      let day = aux.getDate()
      
      aux = [day.toString(),month_name.slice(0,3),year.toString() ].join(" ")
    return aux
}
function milis_to_minutes(milis){
   
    let seconds = Math.round(milis/1000)
    let minutes = Math.floor(seconds/60)
    seconds = seconds%60
    return minutes.toString()+":"+seconds.toString().padStart(2,"0")
}
function clean_data (songs){
  return songs.map( x=>{
    let obj  ={}
    obj.title=x.track.name
    obj.album=x.track.album.name
    obj.date=formate_Date(x.added_at)
    obj.duration=milis_to_minutes(x.track.duration_ms)
    obj.images=x.track.album.images
    obj.artists=x.track.artists.map(y=>{
      return y.name
    })
    return obj
  })
}
async function  getRefresh() {
  let body =   await fetch("https://accounts.spotify.com/api/token", {
  method: "POST",
  body: new URLSearchParams(spotidata),
  headers: {
    "Content-type": "application/x-www-form-urlencoded"
  }
})
    let json = await body.json()
 
    
    localStorage.setItem("client_id",spotidata.client_id)
    localStorage.setItem("refresh_token",json.refresh_token)
    
    access_token = json.access_token
    console.log("refres:"+access_token)
    client_id = spotidata.client_id
    return
}


async function getAccessToken(){
    if( refresh_token ==null){
    await getRefresh()
}
else{
    let body = await fetch("https://accounts.spotify.com/api/token", {
  method: "POST",
  body: new URLSearchParams({
    grant_type: 'refresh_token',
    refresh_token,
    client_id

  }),
  headers: {
    "Content-type": "application/x-www-form-urlencoded"
  }
})

    let json = await body.json()
     localStorage.setItem("refresh_token",json.refresh_token)
 access_token = json.access_token
}

}
async function  getAllSongs() {
 
  all_songs=[]
  offset=0
  while (true){
    body = await fetch(`https://api.spotify.com/v1/me/tracks?offset=${offset}&limit=50`, {
  method: "GET",

  headers: {
    "Authorization": "Bearer "+access_token,
    'Content-Type': 'application/x-www-form-urlencoded'
  }
       })
       json= await body.json()
       all_songs.push(...json.items)
       if ((offset+50) >=  json.total){
        break
       }
       offset+=50
  }
  
  return all_songs
}
var songs
async function  loadAsyncData() {
    await getAccessToken()
    console.log(access_token)
      let body = await fetch("https://api.spotify.com/v1/me", {
  method: "GET",

  headers: {
    "Authorization": "Bearer "+access_token,
    'Content-Type': 'application/x-www-form-urlencoded'
  }
       })
       let json= await body.json()

       let name = json.display_name
     
   songs=JSON.parse(localStorage.getItem("songs"))

if (!songs || typeof songs === "undefined" || songs == "undefined"){
    songs =clean_data(await getAllSongs())
    console.log(songs)
    localStorage.setItem("songs",JSON.stringify(songs))

}
       
       let less_songs=songs.slice(0,10)
        
       
      
     
      less_songs=less_songs.map((x,index)=>{

        return `  
              <tr>
                  <td class="song-list_data number">${index+1}</td>
                  <td class="song-list_data title">
                    <img
                      src="${x.images[2].url}"
                    />
                    <div class="song-list_div">
                      <p>
                        ${x.title}
                      </p>
                      <p>${x.artists.join(", ")}</p>
                    </div>
                  </td>

                  <td class="song-list_data album">
                    <div>
                      ${x.album}
                    </div>
                  </td>
                  <td class="song-list_data date">${x.date}</td>

                  <td class="song-list_data duration">${x.duration}</td>
                </tr>
                `
      })
      
      songs_html = less_songs.join("")
      $("#songs-data").html(songs_html)
      console.log(songs_html)
       $( "#main" ).css( "display", "block" );
       $( "#main_object" ).html(`
        <p style="margin-bottom: 1.5rem;"></p>
        <p>
                        Bienvenido<br/>
                        	${name}
						<br />
					</p>
            <p style="margin-bottom: 2rem;"></p>
            <p>
					
						las canciones han sido descargadas
            </p>
             <p style="margin-bottom: 2rem;"></p>
            `)
     $( "#footer_main" ).html(``)
  
}

if (spotidata != null  || refresh_token !=null){
    $( "#main_object" ).html(`<p>
                        Descargando
						<br />
						Infrormación de la cuenta y
						<br />
						Lista de Canciones.
					    </p>`)
     $( "#footer_main" ).html(`
        <div class="sk-folding-cube">
  <div class="sk-cube1 sk-cube"></div>
  <div class="sk-cube2 sk-cube"></div>
  <div class="sk-cube4 sk-cube"></div>
  <div class="sk-cube3 sk-cube"></div>
</div>
`)
loadAsyncData()

     }

$( "#download-button" ).on( "click", function() {
  let filtered_songs =  songs.map( x=>{
          let aux=   x.title +" - "+x.artists[0]
          if(x.artists.length != 1){
            aux += " feat "+x.artists[1]
          }
          return aux
       })
  console.log(filtered_songs)
 $.ajax({
  type: "POST",
  contentType: "application/json",
  url: "/download_songs",
  data: JSON.stringify(filtered_songs),
  success: ()=>{
    console.log("hi")
  },
  dataType: "json"
});
  
} );     
