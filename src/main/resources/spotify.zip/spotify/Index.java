package com.example.spotify;

public class Index {
  // a field to be called username in the template
  private String username;
  // a field to be called email in the template
  private String email;
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }
  public void setEmail(String email) {
    this.email = email;
  }
  public String getEmail() {
    return email;
  }
  
  
  // create Getters and Setters by pressing 'Ctrl + ;'
}