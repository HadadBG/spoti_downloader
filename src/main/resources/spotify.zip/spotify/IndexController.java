package com.example.spotify;



import org.springframework.http.HttpStatus;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.util.UriComponentsBuilder;

import io.github.gaeqs.javayoutubedownloader.JavaYoutubeDownloader;
import io.github.gaeqs.javayoutubedownloader.decoder.MultipleDecoderMethod;
import io.github.gaeqs.javayoutubedownloader.stream.StreamOption;
import io.github.gaeqs.javayoutubedownloader.stream.YoutubeVideo;
import io.github.gaeqs.javayoutubedownloader.stream.download.StreamDownloader;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URLEncoder;
import java.nio.ByteBuffer;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashMap;


@Controller
public class IndexController {
  private byte[] sha256 (String entrada) throws NoSuchAlgorithmException{
    MessageDigest digest = MessageDigest.getInstance("SHA-256");
    ByteBuffer buf =StandardCharsets.UTF_8.encode(entrada);
    byte[] arr = new byte[buf.remaining()];
    buf.get(arr);
    
    return digest.digest(arr);

  }
  private String base64encode (byte[] bites){

    return new String( Base64.getEncoder().encode(bites),StandardCharsets.UTF_8)
    .replace("=", "").replace("+", "-").replace("/", "_");
  }
 
  // A GET request to the 'welcome' endpoint
  private String generateRandomString(int len){
    SecureRandom random = new SecureRandom();
    ArrayList<Integer> values= new ArrayList<Integer>();
    for (int i=0 ; i<len;i++){
      byte[] bucket = new byte[1];
      random.nextBytes(bucket);
      int value=0;
      for (byte b : bucket) {
        value = (value << 8) + (b & 0xFF);
      }
      values.add(value);
    }

    String salida ="";
    final String posisble = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (int randomInt : values){
      salida+=posisble.charAt(randomInt%posisble.length());
    }
    return salida;
  }
  private final String codeVerifier= generateRandomString(64);
  @GetMapping("/")
  public String IndexGET(Model model,@RequestParam(required = false) String code) throws NoSuchAlgorithmException, UnsupportedEncodingException {
    SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();

    Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress("172.20.112.254", 9090));
    requestFactory.setProxy(proxy);
    byte[] hashed = sha256(codeVerifier);
    String codeChallenge = base64encode(hashed);
   
    String clientID ="59feae1e67864f53a889cdf5adf4191e";
    String redirectUri = "http://127.0.0.1:8080";
    String scope = "user-read-private user-read-email playlist-read-private user-library-read";
    String authUrl ="https://accounts.spotify.com/authorize";
    String url =UriComponentsBuilder.fromUriString(authUrl)
    .queryParam("response_type", "code")
    .queryParam("client_id",clientID)
    .queryParam("scope",  URLEncoder.encode(scope,"UTF-8"))
    .queryParam("code_challenge_method", "S256")
    .queryParam("code_challenge", codeChallenge)
    .queryParam("redirect_uri", URLEncoder.encode(redirectUri,"UTF-8"))
    .build().toString();
   
   
    if (code != null && code != "" ){

      
      
 HashMap<String,String> data = new HashMap<String,String>();
        data.put("client_id", clientID);
        data.put("grant_type", "authorization_code");
        data.put("code", code);
        data.put("redirect_uri",  redirectUri);
        data.put("code_verifier", codeVerifier);


        model.addAttribute("spotiMap",data );
        
    }
    model.addAttribute("spotifyUri", url);
    return "indexi";
  }
  @PostMapping("/download_songs")
  @ResponseStatus(code = HttpStatus.OK, reason = "OK")
  public void Download_Songs(@RequestBody ArrayList<String> songs) {
  
   songs=new ArrayList<String>(songs.subList(0, 1));
    System.out.println("downloading...");
    download("https://www.youtube.com/watch?v=hTWKbfoikeg",  new File("C:\\Users\\hbautistag\\Desktop\\prueba\\songs"));
    System.out.println(songs);
   
}
public static boolean download(String url, File folder) {
	//Extracts and decodes all streams.
	YoutubeVideo video = JavaYoutubeDownloader.decodeOrNull(url, MultipleDecoderMethod.AND, "html", "embedded");
	//Gets the option with the greatest quality that has video and audio.
	StreamOption option = video.getStreamOptions().stream()
		.filter(target -> target.getType().hasVideo() && target.getType().hasAudio())
		.min(Comparator.comparingInt(o -> o.getType().getVideoQuality().ordinal())).orElse(null);
	//If there is no option, returns false.
	if (option == null) return false;
	//Prints the option type.
	System.out.println(option.getType());
	//Creates the file. folder/title.extension
	File file = new File(folder, video.getTitle() + "." + option.getType().getContainer().toString().toLowerCase());
	//Creates the downloader.
	StreamDownloader downloader = new StreamDownloader(option, file, null);
	//Runs the downloader.
	new Thread(downloader).start();
	return true;
}
}